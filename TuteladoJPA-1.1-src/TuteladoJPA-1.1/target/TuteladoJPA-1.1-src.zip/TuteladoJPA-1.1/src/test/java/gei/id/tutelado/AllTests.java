package gei.id.tutelado;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ P01_Usuarios.class, P02_Usuarios_Entradas.class, P03_Consultas.class } )
public class AllTests {

}
