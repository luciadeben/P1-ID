package gei.id.tutelado.configuracion;

public interface Configuracion {
	public void start();
	public Object get(String artifact);
	public void endUp();
}
